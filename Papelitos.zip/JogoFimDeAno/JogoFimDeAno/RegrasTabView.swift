//
//  RegrasTabView.swift
//  JogoFimDeAno
//
//  Created by Andre Gerez Foratto on 26/12/23.
//

import SwiftUI

struct RegrasTabView: View {
    
    @State var palavras: String = ""
    @State private var isInputComplete: Bool = false
    @Binding var tabSelection: Int
    @Binding var palavrasFrases: [String]
    @Binding var palavrasPalavras: [String]
    @Binding var palavrasMimicas: [String]
    @Binding var palavrasSons: [String]
    
    var body: some View {
        ZStack {
            Color.purple
                
            VStack {
                Text("Papelitos".uppercased())
                    .font(.system(size: 45, weight: .bold ,design: .monospaced))
                    .foregroundStyle(.yellow)
                    .padding(.top, 90)
                    
                Spacer(minLength: 1)
                    
                Rectangle()
                    .foregroundColor(.yellow)
                    .cornerRadius(20)
                    .padding(.horizontal, 20)
                    .overlay(
                        VStack {
                            Text("Como jogar:")
                                .font(.system(size: 30, weight: .bold ,design: .monospaced))
                                .foregroundStyle(.purple)
                                .padding(.top, 20)
                            
                            Text("(Role para baixo para ler todas as regras)")
                                .font(.system(size: 10, weight: .bold ,design: .monospaced))
                                .foregroundStyle(.purple)
                                .padding(.bottom, 20)
                                
                            ScrollView(showsIndicators: true) {
                                VStack {
                                    Text("Objetivo:".uppercased())
                                        .padding(.top, 10)
                                        .font(.headline)
                                        .foregroundStyle(.purple)
                                        .frame(maxWidth: 294, alignment: .leading)
                                        
                                    Text("Acertar o maior número de palavras em todas as categorias do jogo.")
                                        .padding(.leading, 30)
                                        .padding(.trailing, 30)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                    Text("Passos:".uppercased())
                                        .padding(.top, 10)
                                        .font(.headline)
                                        .foregroundStyle(.purple)
                                        .frame(maxWidth: 294, alignment: .leading)
                                        
                                    Text("**1**: Dividir o grupo de participantes em duas equipes;\n**2**: Cada participante deve digitar três palavras que alimentarão o jogo (porém não é permitido substantivo próprio);\n**3**: Cada jogador possuirá 1 minuto para dar suas dicas. Caso acertem a palavra dentro de 1 minuto, tem direito de seguir para a próxima palavra, até que termine seu tempo;\n**4**: Seguir as categorias conforme a ordem abaixo.")
                                        .padding(.leading, 30)
                                        .padding(.trailing, 30)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                    Text("Categorias:".uppercased())
                                        .padding(.top, 10)
                                        .font(.headline)
                                        .foregroundStyle(.purple)
                                        .frame(maxWidth: 294, alignment: .leading)
                                        
                                    Text("\n**FRASE**: o jogador deve sortear uma das palavras escritas por todos os participantes e fazer com que seu time descubra a palavra por meio de uma frase, mas na frase não pode conter nenhuma palavra derivada daquela que deve ser descoberta. Soma-se 1 ponto ao placar por cada acerto.")
                                        .padding(.leading, 30)
                                        .padding(.trailing, 30)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                    Text("\n**PALAVRA**: o jogador deve sortear uma das palavras escritas por todos os participantes e fazer com que seu time descubra a palavra por meio de uma outra palavra, mas que não seja derivada daquela que deve ser descoberta. Soma-se 1 ponto ao placar por cada acerto.")
                                        .padding(.leading, 30)
                                        .padding(.trailing, 30)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                    Text("\n**MÍMICA**: o jogador deve sortear uma das palavras escritas por todos os participantes e fazer com que seu time descubra a palavra por meio de uma mímica, mas não é permitido emitir qualquer som. Soma-se 1 ponto ao placar por cada acerto.")
                                        .padding(.leading, 30)
                                        .padding(.trailing, 30)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                    Text("\n**SOM**: o jogador deve sortear uma das palavras escritas por todos os participantes e fazer com que seu time descubra a palavra por meio de um som, mas não é permitido realizar qualquer tipo de mímica. Soma-se 1 ponto ao placar por cada acerto.")
                                        .padding(.leading, 30)
                                        .padding(.trailing, 30)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                    Text("\nAo final, ganha o time que somou mais pontos durante todo o ciclo do jogo.")
                                        .padding(.leading, 30)
                                        .padding(.trailing, 30)
                                        .padding(.bottom, 20)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }
                        }
                    )
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                
                TextField("Digite sua palavra...", text: $palavras)
                    .padding()
                    .background(Color.white)
                    .italic()
                    .foregroundColor(.purple)
                    .cornerRadius(10)
                    .padding(.top, 15)
                    .padding(.horizontal, 30)
                    .padding(.bottom, 15)
                    
                HStack {
                    Button(action: {
                        // Adicionar a palavra ao array quando o botão "-->" é pressionado
                        if !palavras.isEmpty {
                            palavrasFrases.append(palavras)
                            palavrasPalavras.append(palavras)
                            palavrasMimicas.append(palavras)
                            palavrasSons.append(palavras)
                            palavras = ""
                        }
                    }) {
                        Image(systemName: "arrow.right")
                            .font(.system(size: 20))
                            .padding(.horizontal, 65)
                            .padding(.vertical, 15)
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
                Spacer(minLength: 50)
            }
        }
        .ignoresSafeArea(.all, edges: .top)
    }
}

#Preview {
    RegrasTabView(tabSelection: .constant(0), palavrasFrases: .constant([]), palavrasPalavras: .constant([]), palavrasMimicas: .constant([]), palavrasSons: .constant([]))
}
