//
//  ContentView.swift
//  JogoFimDeAno
//
//  Created by Andre Gerez Foratto on 26/12/23.
//

import SwiftUI
import AVFoundation

struct ContentView: View {
    
    @State private var tabSelection: Int = 0
    @State private var palavrasFrases: [String] = []
    @State private var palavrasPalavras: [String] = []
    @State private var palavrasMimicas: [String] = []
    @State private var palavrasSons: [String] = []
    
    //Variáveis para contabilizar os pontos das equipes azul e vermelha
    @State private var pontoVermelha: Int = 0
    @State private var pontoAzul: Int = 0
    
    var body: some View {
        TabView(selection: $tabSelection) {
            RegrasTabView(tabSelection: $tabSelection, palavrasFrases: $palavrasFrases, palavrasPalavras: $palavrasPalavras, palavrasMimicas: $palavrasMimicas, palavrasSons: $palavrasSons)
                .tabItem {
                    Label("Regras", systemImage: "text.magnifyingglass")
                }
                .tag(0)
            
            FraseTabView(tabSelection: $tabSelection, palavrasFrases: $palavrasFrases, pontoVermelha: $pontoVermelha, pontoAzul: $pontoAzul)
                .tabItem {
                    Label("Frase", systemImage: "message")
                }
                .tag(1)
            
            PalavraTabView(tabSelection: $tabSelection, palavrasPalavras: $palavrasPalavras, pontoVermelha: $pontoVermelha, pontoAzul: $pontoAzul)
                .tabItem {
                    Label("Palavra", systemImage: "textformat")
                }
                .tag(2)
            
            MimicaTabView(tabSelection: $tabSelection, palavrasMimicas: $palavrasMimicas, pontoVermelha: $pontoVermelha, pontoAzul: $pontoAzul)
                .tabItem {
                    Label("Mímica", systemImage: "figure")
                }
                .tag(3)
            
            SomTabView(tabSelection: $tabSelection, palavrasSons: $palavrasSons, pontoVermelha: $pontoVermelha, pontoAzul: $pontoAzul)
                .tabItem {
                    Label("Som", systemImage: "speaker.wave.2")
                }
                .tag(4)
        }
    }
}

#Preview {
    ContentView()
}
