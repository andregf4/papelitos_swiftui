//
//  FraseTabView.swift
//  JogoFimDeAno
//
//  Created by Andre Gerez Foratto on 26/12/23.
//

//View para o sorteio das palavras que devem ser adivinhadas por meio de uma frase

import SwiftUI
import AVFoundation

struct FraseTabView: View {
    
    @State private var isCategoryPhraseComplete: Bool = false
    @State var palavraSorteada: String?
    @Binding var tabSelection: Int
    @Binding var palavrasFrases: [String]
    
    //Variáveis para a pontuação
    @Binding var pontoVermelha: Int
    @Binding var pontoAzul: Int
    
    //Variáveis para o cronômetro:
    @State private var tempoSobrando: TimeInterval = 60
    @State private var timer: Timer?
    @State private var estaContando: Bool = false 
    
    @State var player: AVAudioPlayer?
    @State var selectedSound: String = "alarm"

    func playSound() {
        guard let soundURL = Bundle.main.url(forResource: selectedSound, withExtension: "wav") else {
            return
        }
        do {
            player = try AVAudioPlayer(contentsOf: soundURL)
        } catch {
            print("Failed to load the sound: \(error)")
        }
        player?.play()
    }
    
    //------------------------------
        
    var body: some View {
        ZStack {
            Color.purple
            
            VStack {
                Text("FRASE".uppercased())
                    .font(.system(size: 60, weight: .bold ,design: .monospaced))
                    .foregroundStyle(.yellow)
                    .padding(.bottom, 5)
                
                ZStack {
                    Circle()
                        .stroke(lineWidth: 2)
                        .opacity(0.3)
                        .frame(width: 100, height: 100)
                    Circle()
                        .trim(from: 0, to: CGFloat(1 - (tempoSobrando / 60)))
                        .stroke(style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
                        .rotationEffect(.degrees(-90))
                        .frame(width: 100, height: 100)
                        .foregroundStyle(.yellow)
                    Button {
                        estaContando.toggle()
                        if estaContando {
                            startTimer()
                        } else {
                            stopTimer()
                        }
                    } label: {
                        Image(systemName: "clock")
                            .font(.system(size: 80))
                            .foregroundStyle(.white)
                            .padding(.bottom, 10)
                            .frame(width: 100, height: 100)
                            .offset(x: 0, y: 4.5)
                    }
                    
                    //BOTÕES PARA A PONTUAÇÃO
                    Button {
                        pontoVermelha += 1
                    } label: {
                        Image(systemName: "triangle.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(.red)
                            .padding(.bottom, 10)
                            .frame(width: 100, height: 100)
                    }
                    .offset(x: -100, y: -20)
                    
                    Text("\(pontoVermelha)")
                        .offset(x: -100, y: 5)
                        .font(.system(size: 20, design: .monospaced))
                        .foregroundStyle(.white)
                    
                    Button {
                        pontoVermelha -= 1
                    } label: {
                        Image(systemName: "triangle.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(.red)
                            .padding(.bottom, 10)
                            .rotationEffect(.degrees(180))
                    }
                    .offset(x: -100, y: 30)
                    
                    Button {
                        pontoAzul += 1
                    } label: {
                        Image(systemName: "triangle.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(.cyan)
                            .padding(.bottom, 10)
                            .frame(width: 100, height: 100)
                            
                    }
                    .offset(x: 100, y: -20)
                    
                    Text("\(pontoAzul)")
                        .offset(x: 100, y: 5)
                        .font(.system(size: 20, design: .monospaced))
                        .foregroundStyle(.white)
                    
                    Button {
                        pontoAzul -= 1
                    } label: {
                        Image(systemName: "triangle.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(.cyan)
                            .padding(.bottom, 10)
                            .rotationEffect(.degrees(180))
                    }
                    .offset(x: 100, y: 30)
                    
                }
                
                ZStack {
                    Rectangle()
                        .foregroundColor(.yellow)
                        .cornerRadius(20)
                        .padding(.top, 20)
                        .padding(.bottom, 70)
                        .frame(width: 300, height: 300)
                        .overlay(
                            Text(palavraSorteada ?? "")
                                .font(.system(size: 30, design: .monospaced))
                                .padding(.bottom, 50)
                                .animation(.easeInOut(duration: 0.5), value: UUID())
                        )
                    
                    Image(systemName: "message.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.purple)
                        .offset(x: -130, y: -110)
                    
                    Image(systemName: "message.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.purple)
                        .offset(x: 130, y: -110)
                    
                    Image(systemName: "message.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.purple)
                        .offset(x: 130, y: 60)
                    
                    Image(systemName: "message.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.purple)
                        .offset(x: -130, y: 60)
                }
                
                Button(action: {
                    // Sorteia uma palavra aleatória do array 'wordsArray'
                    if !palavrasFrases.isEmpty {
                        // Sorteia uma palavra aleatória
                        let randomIndex = Int.random(in: 0..<palavrasFrases.count)
                        palavraSorteada = palavrasFrases[randomIndex]
                        palavrasFrases.remove(at: randomIndex)
                    } else {
                        tabSelection = 2
                    }
                }) {
                    Text("sortear".uppercased())
                        .padding(.horizontal, 65)
                        .padding(.vertical, 15)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                }
            }
            
            if palavrasFrases.isEmpty {
                Rectangle()
                    .frame(width: .infinity, height: 50)
                    .overlay(
                        Text("última palavra")
                            .foregroundStyle(Color.white)
                            .font(.system(size: 30, design: .rounded))
                            
                    )
                    .foregroundStyle(Color.darkpurple)
                    .offset(x: 0, y: 180)
            }
        }
        .ignoresSafeArea(.all, edges: .top)
    }
    
    //Funções para o cronômetro:

    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if tempoSobrando > 0 {
                tempoSobrando -= 1
            } else {
                stopTimer()
            }
        }
    }
    
    private func stopTimer() {
        estaContando = false
        timer?.invalidate()
        playSound()
        tempoSobrando = 60
    }
}

#Preview {
    FraseTabView(tabSelection: .constant(1), palavrasFrases: .constant([]), pontoVermelha: .constant(0), pontoAzul: .constant(0))
}
