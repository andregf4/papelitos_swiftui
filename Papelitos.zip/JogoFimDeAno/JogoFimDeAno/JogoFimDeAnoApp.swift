//
//  JogoFimDeAnoApp.swift
//  JogoFimDeAno
//
//  Created by Andre Gerez Foratto on 26/12/23.
//

import SwiftUI

@main
struct JogoFimDeAnoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
